jQZoom Product Page (vQmod)
By Ricky Nugroho (http://rocanowi.com/)
Last update: 01-Apr-2013
License: BSD License (see LICENSE.txt)


====================
DESCRIPTION:
====================
It will replace the default zoom method in Opencart's product page with the jQZoom the Javascript Image Magnifier by Marco Renzi (http://www.mind-projects.it/projects/jqzoom/).
====================


====================
COMPATIBILITY:
====================
Tested in v1.5.2, v1.5.2.1, v1.5.3, v1.5.3.1, v1.5.4, v1.5.4.1, v1.5.5, v1.5.5.1
Different version for v1.5.5 - v1.5.5.1
====================


====================
HOW TO INSTALL:
====================
1. Install vQmod and make sure it is installed! This extension need vQmod. Otherwise it will not work properly. REMEMBER you must install vQmod v2.1.7 or newer for Opencart v1.5.4 or newer.
2. Upload all the files and folder in "upload" folder to your Opencart directory. Don't worry, no Opencart's files replaced!
3. Check how extension doing :).
====================


====================
HOW TO CONFIGURE THE jQZoom SETTING:
====================
1. Open file "vqmod/xml/rcn_jqzoom_product.xml".
2. Find this code:

	<script type="text/javascript">
	$(document).ready(function() {
	  $('.jqzoom').jqzoom({
		zoomType: 'standard',
		lens:true,
		preloadImages: false,
		alwaysOn:false,
		xOffset: 20, 
		yOffset: -10,
		zoomWidth: 330,  
		zoomHeight: 350
	  });
	});
	</script>
	
3. That is the jQZoom configuration. You can modified it to match your need. Find the configuration option at http://www.mind-projects.it/projects/jqzoom/.
4. Save your modification.
5. Upload the *.xml file to "vqmod/xml/".
6. Check how extension doing :).
====================


====================
HOW TO CONFIGURE THE IMAGE SIZE INSIDE jQZoom:
====================
1. Login to your Opencart Administration Page.
2. Go to "System->Settings" menu.
3. Edit your store.
4. Go to "Image" tab.
5. Change size in the "Product Image Popup Size" setting.
6. Save the setting.
7. Check how extension doing :).
====================


====================
HOW TO UNINSTALL:
====================
1. Just remove the *.xml file in "vqmod/xml/rcn_jqzoom_product.xml" and everything will be normal again. There are other files in this extension, but they are not necessary to remove.
2. Check how extension doing :).
====================


====================
CHANGELOG:
====================
01-Apr-2013
- Add new version for Opencart v1.5.5 and v1.5.5.1.

08-Dec-2012
- Fix: The VQMod now should be works for all custom template by changing the "default" folder to "*" in the XML.
- Fix: Website menu will not fall behind product images by changing the CSS class .zoomPad z-index into 1 in file jquery.jqzoom.css.
====================


By the way, I modified "jquery.jqzoom-core-pack.js" a bit, so it can take negative number on "yOffset" setting.

And don't forget to donate, especially to Opencart and Marco Renzi (who make this awesome jQZoom script).

Thanks.

Regards,
Ricky Nugroho
http://rocanowi.com/